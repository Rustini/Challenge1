interface CallBack {

    fun calculateWinner(Result: String)
}

fun CallBack.calculateWinner(Result: String) {
    TODO("Not yet implemented")
}
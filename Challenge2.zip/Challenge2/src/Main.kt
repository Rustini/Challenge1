
class Main {
    companion object : CallBack {

        @JvmStatic
        fun main(args: Array<String>) {
            //Inisialisasi pilihan
            val pilihan = arrayOf("gunting", "batu", "kertas")

            //Menangkap Pilihan Pemain
            println("Masukan Antara (Gunting, Batu, Kertas) ")
            print("Pemain 1 : ")
            var player1 = readLine()

            print("Pemain 2 : ")
            var player2 = readLine()

        }
        override fun calculateWinner(Result: String) = println("hasil nya adalah $Result")
    }
}


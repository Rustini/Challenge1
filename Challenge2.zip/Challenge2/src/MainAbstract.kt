enum class MainAbstract(val resultValue: String) {
    PEMAIN_1_MENANG("Pemain 1 Menang!"),
    PEMAIN_2_MENANG("Pemain 2 Menang!"),
    DRAW("DRAW"),
    EXIT("")
}